source env/bin/activate
python app.py
