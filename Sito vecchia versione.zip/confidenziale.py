databaseaddress_capitolare = 'mysql+pymysql://giacomo:!Test2020?@157.27.222.38:3306/capitolare'
databaseaddress_capitolare_mongo = "mongodb+srv://Giacomo:9insW5DhYHBi9mF@cluster0.nsmk8.mongodb.net/Project_Cap?retryWrites=true&w=majority"
databaseaddress_capitolare_mongo ="mongodb+srv://giacomo:univr@cluster0.wjdtk.mongodb.net/testcapit?retryWrites=true&w=majority"     
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
